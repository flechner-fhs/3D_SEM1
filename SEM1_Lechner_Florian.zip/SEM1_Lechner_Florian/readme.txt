Die Rückseite vom UV der Karten ist absichtlich geflippt um die Textur der Vorderseite wiederverwenden zu können.

In der Scene verwende ich ein Point Light und ein Spotlight, für einen schöneren Helligkeitsverlauf.

Ich habe ein paar Kameras mit Beispiel-Einstellungen in die Szene gesetzt um mir ein besseres Bild davon zu machen wie das ganze in einem echten Projekt aussehen würde.

Die Blutlache ist eine einfache Plane mit Cut-Out-Textur, weshalb ich dafür kein wirkliches Modell oder UV habe. Sehen Sie sie einfach als Deko um die Szene besser auszuschmücken.