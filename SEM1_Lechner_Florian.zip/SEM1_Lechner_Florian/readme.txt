Die Rückseite vom UV der Karten ist absichtlich geflippt um die Textur der Vorderseite wiederverwenden zu können.

In der Scene verwende ich ein Point Light und ein Spotlight, für einen schöneren Helligkeitsverlauf.

Die Lightmap hat nur 1024x1024, weil mein PC das baken bei 2048 nicht packt. Meine GPU stürzt ab und meine CPU hängt sich auf wenn ich es versuche.

Ich habe ein paar Kameras mit Beispiel-Einstellungen in die Szene gesetzt um mir ein besseres Bild davon zu machen wie das ganze in einem echten Projekt aussehen würde.

Die Blutlache ist eine einfache Plane mit Cut-Out-Textur, weshalb ich dafür kein wirkliches Modell oder UV habe. Sehen Sie sie einfach als Deko um die Szene besser auszuschmücken.